import LandingPage from "./(landing-page)/conzooming/page";

export default function Home() {
  return (
    <main className="">
      <LandingPage />
    </main>
  );
}
